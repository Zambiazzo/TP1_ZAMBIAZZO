#' ---
#' title: "Este es un archivo .R"
#' author: "TuQmano"
#' date: "15/06/2021"
#' ---


#' # Los archivos .R necesitan del # para insertar comentarios

# Este es un comentario normal

electorAr::show_available_elections(source = "results")







